import components.module.Console;
import components.ui.MainFrame;

public class Main {

    public static void main(String[] args) {
        new MainFrame(new Console());
    }
}