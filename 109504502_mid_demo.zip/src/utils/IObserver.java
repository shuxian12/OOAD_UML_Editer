package utils;

public interface IObserver {
    public void update();
}
