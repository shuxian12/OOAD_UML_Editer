package utils;

import java.awt.Graphics2D;

public interface IDraw {
     void draw(Graphics2D g);
}
